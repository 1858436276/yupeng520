import 'dart:io';

import 'package:cloudreve4_flutter/data/models/download_task_model.dart';
import 'package:cloudreve4_flutter/presentation/providers/download_manager_provider.dart';
import 'package:cloudreve4_flutter/presentation/widgets/download_progress_item.dart';
import 'package:cloudreve4_flutter/core/utils/date_utils.dart' as date_utils;
import 'package:cloudreve4_flutter/services/download_service.dart';
import 'package:cloudreve4_flutter/services/task_database.dart';
import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:open_file/open_file.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cloudreve4_flutter/presentation/widgets/toast_helper.dart';
import 'package:cloudreve4_flutter/core/utils/app_logger.dart';

class DownloadTasksTab extends StatefulWidget {
  const DownloadTasksTab({super.key});

  @override
  State<DownloadTasksTab> createState() => _DownloadTasksTabState();
}

class _DownloadTasksTabState extends State<DownloadTasksTab> {
  static const int _pageSize = 15;

  /// 进行中任务当前页码（0-based）
  int _activePage = 0;

  /// 失败/取消任务当前页码（0-based）
  int _failedPage = 0;

  /// 已完成任务当前页码（0-based）
  int _completedPage = 0;

  // ============ 分页 Stream ============

  Stream<List<DownloadTaskEntry>> _failedTasksStream() {
    return TaskDatabase.instance.watchDownloadTasks(
      statusIndexes: [
        DownloadStatus.failed.index,
        DownloadStatus.cancelled.index,
      ],
      limit: _pageSize,
      offset: _failedPage * _pageSize,
    );
  }

  Stream<int> _failedTasksCountStream() {
    return TaskDatabase.instance.watchDownloadTasksCount([
      DownloadStatus.failed.index,
      DownloadStatus.cancelled.index,
    ]);
  }

  Stream<List<DownloadTaskEntry>> _completedTasksStream() {
    return TaskDatabase.instance.watchDownloadTasks(
      statusIndexes: [DownloadStatus.completed.index],
      limit: _pageSize,
      offset: _completedPage * _pageSize,
    );
  }

  Stream<int> _completedTasksCountStream() {
    return TaskDatabase.instance.watchDownloadTasksCount([
      DownloadStatus.completed.index,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer<DownloadManagerProvider>(
      builder: (context, downloadManager, _) {
        // 进行中任务走内存（waiting/downloading/archiving/paused）
        final allTasks = downloadManager.tasks;
        final activeTasks = allTasks
            .where(
              (t) =>
                  t.status == DownloadStatus.archiving ||
                  t.status == DownloadStatus.downloading ||
                  t.status == DownloadStatus.waiting ||
                  t.status == DownloadStatus.paused,
            )
            .toList();

        return LayoutBuilder(
          builder: (context, constraints) {
            final isDesktop = constraints.maxWidth >= 800;

            if (isDesktop) {
              return _buildDesktopLayout(context, downloadManager, activeTasks);
            }

            return _buildMobileLayout(context, downloadManager, activeTasks, theme);
          },
        );
      },
    );
  }

  // ============ Mobile Layout ============

  Widget _buildMobileLayout(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
    ThemeData theme,
  ) {
    return ListView(
      padding: const EdgeInsets.only(top: 8, bottom: 80),
      children: [
        _buildActiveSection(context, downloadManager, activeTasks),
        _buildFailedSection(context, downloadManager, activeTasks, theme),
        _buildCompletedSection(context, downloadManager, activeTasks, theme),
      ],
    );
  }

  /// 进行中任务分页 section（内存数据，避免大量任务全量渲染卡死）
  Widget _buildActiveSection(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
  ) {
    if (activeTasks.isEmpty) return const SizedBox.shrink();

    final totalCount = activeTasks.length;
    final totalPages = (totalCount / _pageSize).ceil();
    if (_activePage >= totalPages) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          setState(() => _activePage = (totalPages - 1).clamp(0, totalPages - 1));
        }
      });
    }
    final safePage = _activePage.clamp(0, totalPages - 1);
    final start = safePage * _pageSize;
    final end = (start + _pageSize).clamp(0, totalCount);
    final pageTasks = activeTasks.sublist(start, end);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSectionHeader(context, '进行中', totalCount),
        ...pageTasks.map(
          (task) => DownloadProgressItem(
            task: task,
            onPause: () => downloadManager.pauseDownload(task.id),
            onResume: () => downloadManager.resumeDownload(task.id),
            onCancel: () => downloadManager.cancelDownload(task.id),
          ),
        ),
        _buildPaginationControls(
          context: context,
          currentPage: safePage,
          totalPages: totalPages,
          onPrev: safePage > 0
              ? () => setState(() => _activePage--)
              : null,
          onNext: safePage < totalPages - 1
              ? () => setState(() => _activePage++)
              : null,
        ),
      ],
    );
  }

  Widget _buildFailedSection(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
    ThemeData theme,
  ) {
    return StreamBuilder<int>(
      stream: _failedTasksCountStream(),
      builder: (context, countSnapshot) {
        final totalCount = countSnapshot.data ?? 0;
        if (totalCount == 0) return const SizedBox.shrink();
        final totalPages = (totalCount / _pageSize).ceil();
        if (_failedPage >= totalPages) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) setState(() => _failedPage = (totalPages - 1).clamp(0, totalPages - 1));
          });
        }
        return StreamBuilder<List<DownloadTaskEntry>>(
          stream: _failedTasksStream(),
          builder: (context, snapshot) {
            final entries = snapshot.data ?? const [];
            final failedTasks = entries
                .map((e) => DownloadTaskModel.fromEntry(e))
                .toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSectionHeader(
                  context,
                  '失败',
                  totalCount,
                  actionLabel: '清除失败',
                  onAction: () => _confirmClear(
                    context,
                    '失败',
                    totalCount,
                    () {
                      downloadManager.clearFailedTasks();
                      setState(() => _failedPage = 0);
                    },
                  ),
                ),
                ...failedTasks.map(
                  (task) => DownloadProgressItem(
                    task: task,
                    onRetry: () => downloadManager.retryDownload(task.id),
                    onDelete: () =>
                        _confirmDeleteDownloadTask(context, task, downloadManager),
                  ),
                ),
                _buildPaginationControls(
                  context: context,
                  currentPage: _failedPage,
                  totalPages: totalPages,
                  onPrev: _failedPage > 0
                      ? () => setState(() => _failedPage--)
                      : null,
                  onNext: _failedPage < totalPages - 1
                      ? () => setState(() => _failedPage++)
                      : null,
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCompletedSection(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
    ThemeData theme,
  ) {
    return StreamBuilder<int>(
      stream: _completedTasksCountStream(),
      builder: (context, countSnapshot) {
        final totalCount = countSnapshot.data ?? 0;
        if (totalCount == 0) {
          // 进行中、失败都为空 + 已完成也在 loading 或为 0 -> 显示空态
          if (activeTasks.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    LucideIcons.download,
                    size: 48,
                    color: theme.hintColor.withValues(alpha: 0.4),
                  ),
                  const SizedBox(height: 16),
                  Text('暂无下载任务', style: TextStyle(color: theme.hintColor)),
                ],
              ),
            );
          }
          return const SizedBox.shrink();
        }
        final totalPages = (totalCount / _pageSize).ceil();
        if (_completedPage >= totalPages) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) setState(() => _completedPage = (totalPages - 1).clamp(0, totalPages - 1));
          });
        }
        return StreamBuilder<List<DownloadTaskEntry>>(
          stream: _completedTasksStream(),
          builder: (context, snapshot) {
            final entries = snapshot.data ?? const [];
            final completedTasks = entries
                .map((e) => DownloadTaskModel.fromEntry(e))
                .toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSectionHeader(
                  context,
                  '已完成',
                  totalCount,
                  actionLabel: '清除已完成',
                  onAction: () => _confirmClear(
                    context,
                    '已完成',
                    totalCount,
                    () {
                      downloadManager.clearCompletedTasks();
                      setState(() => _completedPage = 0);
                    },
                  ),
                ),
                ...completedTasks.map(
                  (task) => DownloadProgressItem(
                    task: task,
                    onDelete: () =>
                        _confirmDeleteDownloadTask(context, task, downloadManager),
                  ),
                ),
                _buildPaginationControls(
                  context: context,
                  currentPage: _completedPage,
                  totalPages: totalPages,
                  onPrev: _completedPage > 0
                      ? () => setState(() => _completedPage--)
                      : null,
                  onNext: _completedPage < totalPages - 1
                      ? () => setState(() => _completedPage++)
                      : null,
                ),
              ],
            );
          },
        );
      },
    );
  }

  /// 分页控件：[上一页] 第 X/Y 页 [下一页]
  Widget _buildPaginationControls({
    required BuildContext context,
    required int currentPage,
    required int totalPages,
    VoidCallback? onPrev,
    VoidCallback? onNext,
  }) {
    if (totalPages <= 1) return const SizedBox.shrink();

    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left, size: 20),
            onPressed: onPrev,
            tooltip: '上一页',
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            color: onPrev == null ? theme.disabledColor : theme.colorScheme.primary,
          ),
          const SizedBox(width: 12),
          Text(
            '第 ${currentPage + 1} / $totalPages 页',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.hintColor,
            ),
          ),
          const SizedBox(width: 12),
          IconButton(
            icon: const Icon(Icons.chevron_right, size: 20),
            onPressed: onNext,
            tooltip: '下一页',
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            color: onNext == null ? theme.disabledColor : theme.colorScheme.primary,
          ),
        ],
      ),
    );
  }

  // ============ Desktop Layout ============

  Widget _buildDesktopLayout(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
  ) {
    final colorScheme = Theme.of(context).colorScheme;

    // 对 active 任务分页，避免大量 DataRow 全量渲染卡死 DataTable
    final activeTotal = activeTasks.length;
    final activeTotalPages = activeTotal == 0 ? 0 : (activeTotal / _pageSize).ceil();
    if (activeTotalPages > 0 && _activePage >= activeTotalPages) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          setState(() => _activePage = (activeTotalPages - 1).clamp(0, activeTotalPages - 1));
        }
      });
    }
    final activeSafePage = activeTotalPages > 0
        ? _activePage.clamp(0, activeTotalPages - 1)
        : 0;
    final activeStart = activeSafePage * _pageSize;
    final activeEnd = (activeStart + _pageSize).clamp(0, activeTotal);
    final pagedActiveTasks = activeTasks.sublist(activeStart, activeEnd);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // 失败任务的清除按钮
          StreamBuilder<int>(
            stream: _failedTasksCountStream(),
            builder: (context, snapshot) {
              final failedCount = snapshot.data ?? 0;
              if (failedCount == 0) return const SizedBox.shrink();
              return Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: TextButton.icon(
                    icon: const Icon(LucideIcons.trash2, size: 14),
                    label: const Text('清除失败', style: TextStyle(fontSize: 12)),
                    onPressed: () => _confirmClear(
                      context,
                      '失败',
                      failedCount,
                      () {
                        downloadManager.clearFailedTasks();
                        setState(() => _failedPage = 0);
                      },
                    ),
                    style: TextButton.styleFrom(
                      foregroundColor: colorScheme.error,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 4,
                      ),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
              );
            },
          ),
          // 已完成任务的清除按钮（仅在失败任务为空时显示）
          StreamBuilder<int>(
            stream: _failedTasksCountStream(),
            builder: (context, failedSnapshot) {
              final failedCount = failedSnapshot.data ?? 0;
              if (failedCount > 0) return const SizedBox.shrink();
              return StreamBuilder<int>(
                stream: _completedTasksCountStream(),
                builder: (context, completedSnapshot) {
                  final completedCount = completedSnapshot.data ?? 0;
                  if (completedCount == 0) return const SizedBox.shrink();
                  return Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TextButton.icon(
                        icon: const Icon(LucideIcons.trash2, size: 14),
                        label: const Text('清除已完成', style: TextStyle(fontSize: 12)),
                        onPressed: () => _confirmClear(
                          context,
                          '已完成',
                          completedCount,
                          () {
                            downloadManager.clearCompletedTasks();
                            setState(() => _completedPage = 0);
                          },
                        ),
                        style: TextButton.styleFrom(
                          foregroundColor: colorScheme.error,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 4,
                          ),
                          minimumSize: Size.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
          SizedBox(
            width: double.infinity,
            child: Card(
              margin: EdgeInsets.zero,
              clipBehavior: Clip.antiAlias,
              child: _buildTasksDataTable(context, downloadManager, pagedActiveTasks),
            ),
          ),
          // 进行中任务分页控件
          if (activeTotalPages > 1)
            _buildPaginationControls(
              context: context,
              currentPage: activeSafePage,
              totalPages: activeTotalPages,
              onPrev: activeSafePage > 0
                  ? () => setState(() => _activePage--)
                  : null,
              onNext: activeSafePage < activeTotalPages - 1
                  ? () => setState(() => _activePage++)
                  : null,
            ),
          // 已完成任务分页控件
          StreamBuilder<int>(
            stream: _completedTasksCountStream(),
            builder: (context, snapshot) {
              final totalCount = snapshot.data ?? 0;
              if (totalCount <= _pageSize) return const SizedBox.shrink();
              final totalPages = (totalCount / _pageSize).ceil();
              return _buildPaginationControls(
                context: context,
                currentPage: _completedPage,
                totalPages: totalPages,
                onPrev: _completedPage > 0
                    ? () => setState(() => _completedPage--)
                    : null,
                onNext: _completedPage < totalPages - 1
                    ? () => setState(() => _completedPage++)
                    : null,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTasksDataTable(
    BuildContext context,
    DownloadManagerProvider downloadManager,
    List<DownloadTaskModel> activeTasks,
  ) {
    return StreamBuilder<List<DownloadTaskEntry>>(
      stream: _failedTasksStream(),
      builder: (context, failedSnapshot) {
        final failedTasks = (failedSnapshot.data ?? const [])
            .map((e) => DownloadTaskModel.fromEntry(e))
            .toList();
        return StreamBuilder<List<DownloadTaskEntry>>(
          stream: _completedTasksStream(),
          builder: (context, completedSnapshot) {
            final completedTasks = (completedSnapshot.data ?? const [])
                .map((e) => DownloadTaskModel.fromEntry(e))
                .toList();

            final sortedTasks = <DownloadTaskModel>[
              ...activeTasks.reversed,
              ...failedTasks.reversed,
              ...completedTasks.reversed,
            ];

            if (sortedTasks.isEmpty) {
              return SizedBox(
                height: 200,
                child: Center(
                  child: Text('暂无下载任务',
                      style: TextStyle(color: Theme.of(context).hintColor)),
                ),
              );
            }

            return DataTable(
              headingRowColor: WidgetStateProperty.all(
                  Theme.of(context).colorScheme.surfaceContainerHighest),
              columnSpacing: 24,
              columns: const [
                DataColumn(label: Text('名称')),
                DataColumn(label: Text('状态')),
                DataColumn(label: Text('进度')),
                DataColumn(label: Text('大小')),
                DataColumn(label: Text('速度/完成时间')),
                DataColumn(label: Text('操作')),
              ],
              rows: sortedTasks
                  .map((task) =>
                      _buildDownloadDataRow(context, task, downloadManager))
                  .toList(),
            );
          },
        );
      },
    );
  }

  DataRow _buildDownloadDataRow(
    BuildContext context,
    DownloadTaskModel task,
    DownloadManagerProvider downloadManager,
  ) {
    final colorScheme = Theme.of(context).colorScheme;
    final errorColor = colorScheme.error;
    final statusColor = _getStatusColor(
      task.status,
      waitingForWifi: task.waitingForWifi,
    );
    final statusIcon = _getStatusIcon(
      task.status,
      waitingForWifi: task.waitingForWifi,
    );
    final isActive =
        task.status == DownloadStatus.archiving ||
        task.status == DownloadStatus.downloading ||
        task.status == DownloadStatus.waiting ||
        task.status == DownloadStatus.paused;

    return DataRow(
      cells: [
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(statusIcon, size: 18, color: statusColor),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  task.fileName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        DataCell(
          Text(
            task.statusText,
            style: TextStyle(color: statusColor, fontSize: 13),
          ),
        ),
        DataCell(
          isActive
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 80,
                      child: LinearProgressIndicator(
                        value:
                            task.status == DownloadStatus.paused ||
                                task.status == DownloadStatus.archiving ||
                                task.fileSize <= 0
                            ? null
                            : task.progress,
                        backgroundColor: colorScheme.surfaceContainerHighest,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          colorScheme.primary,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _getProgressLabel(task),
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                )
              : Text(
                  task.status == DownloadStatus.completed ? '100%' : '-',
                  style: const TextStyle(fontSize: 12),
                ),
        ),
        DataCell(
          Text(
            task.fileSize > 0
                ? DownloadService.getReadableFileSize(task.fileSize)
                : task.downloadedBytes > 0
                ? '${DownloadService.getReadableFileSize(task.downloadedBytes)} / 未知'
                : '未知大小',
            style: const TextStyle(fontSize: 13),
          ),
        ),
        DataCell(
          Text(
            _buildSpeedOrCompletionText(task),
            style: TextStyle(
              fontSize: 13,
              color: task.status == DownloadStatus.completed
                  ? null
                  : (task.speed > 0 ? colorScheme.primary : colorScheme.onSurfaceVariant),
            ),
          ),
        ),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: _buildDesktopActionButtons(
              context,
              task,
              downloadManager,
              errorColor,
            ),
          ),
        ),
      ],
    );
  }

  String _buildSpeedOrCompletionText(DownloadTaskModel task) {
    if (task.status == DownloadStatus.completed) {
      return task.completedAt != null ? _formatDateTime(task.completedAt!) : '-';
    }
    if (task.speed > 0) return task.speedText;
    if (task.status == DownloadStatus.archiving) return '服务端打包中';
    if (task.status == DownloadStatus.waiting) {
      return task.waitingForWifi ? '等待 WiFi' : '等待连接';
    }
    if (task.status == DownloadStatus.downloading) {
      return task.downloadedBytes > 0 ? '持续下载中' : '建立连接中';
    }
    if (task.status == DownloadStatus.paused) return '已暂停';
    return '-';
  }

  String _getProgressLabel(DownloadTaskModel task) {
    if (task.status == DownloadStatus.paused ||
        task.status == DownloadStatus.archiving) {
      return task.downloadedBytes > 0 ? task.progressText : task.statusText;
    }
    return task.progressText;
  }

  List<Widget> _buildDesktopActionButtons(
    BuildContext context,
    DownloadTaskModel task,
    DownloadManagerProvider downloadManager,
    Color errorColor,
  ) {
    switch (task.status) {
      case DownloadStatus.archiving:
      case DownloadStatus.waiting:
        return [
          IconButton(
            icon: Icon(Icons.cancel, size: 18, color: errorColor),
            onPressed: () => downloadManager.cancelDownload(task.id),
            tooltip: '取消',
          ),
        ];
      case DownloadStatus.downloading:
        return [
          if (task.fileSize > 0)
            IconButton(
              icon: const Icon(Icons.pause, size: 18),
              onPressed: () => downloadManager.pauseDownload(task.id),
              tooltip: '暂停',
            ),
          IconButton(
            icon: Icon(Icons.cancel, size: 18, color: errorColor),
            onPressed: () => downloadManager.cancelDownload(task.id),
            tooltip: '取消',
          ),
        ];
      case DownloadStatus.paused:
        return [
          IconButton(
            icon: const Icon(Icons.play_arrow, size: 18),
            onPressed: () => downloadManager.resumeDownload(task.id),
            tooltip: '继续',
          ),
          IconButton(
            icon: Icon(Icons.cancel, size: 18, color: errorColor),
            onPressed: () => downloadManager.cancelDownload(task.id),
            tooltip: '取消',
          ),
        ];
      case DownloadStatus.failed:
        return [
          IconButton(
            icon: const Icon(Icons.refresh, size: 18),
            onPressed: () => downloadManager.retryDownload(task.id),
            tooltip: '重试',
          ),
          IconButton(
            icon: Icon(Icons.delete, size: 18, color: errorColor),
            onPressed: () =>
                _confirmDeleteDownloadTask(context, task, downloadManager),
            tooltip: '删除',
          ),
        ];
      case DownloadStatus.completed:
        final showOpenFolder = !Platform.isAndroid;
        return [
          IconButton(
            icon: const Icon(Icons.open_in_new, size: 18),
            onPressed: () => _openDownloadedFile(context, task),
            tooltip: '打开',
          ),
          if (showOpenFolder)
            IconButton(
              icon: const Icon(Icons.folder_open, size: 18),
              onPressed: () => _openFileFolder(context, task),
              tooltip: '打开文件夹',
            ),
          IconButton(
            icon: Icon(Icons.delete_outline, size: 18, color: errorColor),
            onPressed: () =>
                _confirmDeleteDownloadTask(context, task, downloadManager),
            tooltip: '删除',
          ),
        ];
      case DownloadStatus.cancelled:
        return [];
    }
  }

  IconData _getStatusIcon(
    DownloadStatus status, {
    bool waitingForWifi = false,
  }) {
    switch (status) {
      case DownloadStatus.waiting:
        return waitingForWifi ? LucideIcons.wifi : LucideIcons.clock;
      case DownloadStatus.archiving:
        return LucideIcons.archive;
      case DownloadStatus.downloading:
        return LucideIcons.download;
      case DownloadStatus.completed:
        return LucideIcons.checkCircle2;
      case DownloadStatus.paused:
        return LucideIcons.pause;
      case DownloadStatus.failed:
      case DownloadStatus.cancelled:
        return LucideIcons.xCircle;
    }
  }

  Color _getStatusColor(DownloadStatus status, {bool waitingForWifi = false}) {
    switch (status) {
      case DownloadStatus.waiting:
        return waitingForWifi ? Colors.blue : Colors.grey;
      case DownloadStatus.archiving:
        return Colors.purple;
      case DownloadStatus.downloading:
        return Colors.blue;
      case DownloadStatus.completed:
        return Colors.green;
      case DownloadStatus.paused:
        return Colors.orange;
      case DownloadStatus.failed:
      case DownloadStatus.cancelled:
        return Colors.red;
    }
  }

  Future<void> checkInstallPermission() async {
    if (await Permission.requestInstallPackages.isDenied) {
      await Permission.requestInstallPackages.request();
    }
  }

  Future<void> _openDownloadedFile(
    BuildContext context,
    DownloadTaskModel task,
  ) async {
    final file = File(task.savePath);
    if (!await file.exists()) {
      if (context.mounted) {
        ToastHelper.error('文件不存在：${task.fileName}');
      }
      return;
    }

    try {
      final ext = task.savePath.toString().split('.').last.toLowerCase();
      if (ext == 'apk') {
        await checkInstallPermission();
      }

      OpenResult openResult = await OpenFile.open(task.savePath);
      AppLogger.d('下载对话框打开文件结果：${openResult.type}');
      if (openResult.type == ResultType.done) {
        AppLogger.d('成功打开文件：${task.fileName}');
      } else {
        if (context.mounted) {
          ToastHelper.error(
            '无法打开文件：${task.fileName} 错误信息: ${openResult.message}',
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ToastHelper.error('打开文件失败：$e');
      }
    }
  }

  Future<void> _openFileFolder(
    BuildContext context,
    DownloadTaskModel task,
  ) async {
    try {
      final dir = File(task.savePath).parent.path;
      final result = await OpenFile.open(dir);
      if (result.type != ResultType.done && context.mounted) {
        ToastHelper.error('无法打开文件夹：${result.message}');
      }
    } catch (e) {
      if (context.mounted) {
        ToastHelper.error('打开文件夹失败：$e');
      }
    }
  }

  Widget _buildSectionHeader(
    BuildContext context,
    String title,
    int count, {
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 8, 4),
      child: Row(
        children: [
          Text(
            '$title ($count)',
            style: theme.textTheme.titleSmall?.copyWith(
              color: theme.hintColor,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          if (actionLabel != null && onAction != null)
            TextButton.icon(
              icon: const Icon(LucideIcons.trash2, size: 14),
              label: Text(actionLabel, style: const TextStyle(fontSize: 12)),
              onPressed: onAction,
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.error,
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _confirmClear(
    BuildContext context,
    String label,
    int count,
    VoidCallback onConfirm,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('清除$label'),
        content: Text('确定要清除 $count 个$label的任务吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            child: const Text('清除'),
          ),
        ],
      ),
    );
    if (confirmed == true) onConfirm();
  }

  Future<void> _confirmDeleteDownloadTask(
    BuildContext context,
    DownloadTaskModel task,
    DownloadManagerProvider downloadManager,
  ) async {
    var deleteLocalFile = false;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('删除下载任务'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('确定要删除该任务吗？'),
              const SizedBox(height: 8),
              Text(
                task.fileName,
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 4),
              Text(
                '下载时间: ${_formatDateTime(task.createdAt)}',
                style: TextStyle(fontSize: 12, color: Theme.of(ctx).hintColor),
              ),
              Text(
                '文件大小: ${date_utils.DateUtils.formatFileSize(task.fileSize)}',
                style: TextStyle(fontSize: 12, color: Theme.of(ctx).hintColor),
              ),
              if (task.savePath.isNotEmpty) ...[
                const SizedBox(height: 12),
                CheckboxListTile(
                  value: deleteLocalFile,
                  onChanged: (value) => setState(
                    () => deleteLocalFile = value ?? false,
                  ),
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: const Text('是否删除本地文件'),
                  subtitle: Text(
                    task.savePath,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(ctx).hintColor,
                    ),
                  ),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(ctx).colorScheme.error,
              ),
              child: const Text('删除'),
            ),
          ],
        ),
      ),
    );
    if (confirmed == true) {
      await downloadManager.deleteDownloadTask(
        task.id,
        deleteLocalFile: deleteLocalFile,
      );
    }
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inSeconds < 60) {
      return '刚刚';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}分钟前';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}小时前';
    } else {
      return '${dateTime.month}/${dateTime.day} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
    }
  }
}
